# utf-8
# Python 3.10.0
# 2022-03-08


from feature_utils.core import FeatureMaker


__version__ = "1.0"
